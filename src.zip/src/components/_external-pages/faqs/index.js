export { default as FaqsHero } from './FaqsHero';
export { default as FaqsList } from './FaqsList';
export { default as FaqsForm } from './FaqsForm';
export { default as FaqsCategory } from './FaqsCategory';
